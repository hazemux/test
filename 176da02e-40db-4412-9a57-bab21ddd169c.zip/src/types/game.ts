export type GameId = 'pulse' | 'shield' | 'balance' | 'sequence' | 'catch' | 'focus';

export type GamePhase = 'ready' | 'playing' | 'done';

export type Medal = 'bronze' | 'silver' | 'gold';

export interface RewardTier {
  medal: Medal;
  label: string;
  points: number;
  threshold: number;
}

export interface GameMeta {
  id: GameId;
  number: string;
  name: string;
  styleLabel: string;
  instruction: string;
  scoreLabel: string;
  scoreUnit: string;
  maxScore: number;
  playTime: string;
  tiers: RewardTier[];
}

export interface GameResult {
  score: number;
  detail: string;
}

export interface GameProps {
  phase: GamePhase;
  onProgress: (score: number) => void;
  onComplete: (result: GameResult) => void;
}