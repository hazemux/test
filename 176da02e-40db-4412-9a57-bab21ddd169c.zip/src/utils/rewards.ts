import type { GameMeta, RewardTier } from '../types/game';

export function achievedTierIndex(score: number, tiers: RewardTier[]): number {
  let index = -1;
  tiers.forEach((tier, i) => {
    if (score >= tier.threshold) index = i;
  });
  return index;
}

export function formatScore(meta: GameMeta, score: number): string {
  return `${Math.round(score)}${meta.scoreUnit}`;
}