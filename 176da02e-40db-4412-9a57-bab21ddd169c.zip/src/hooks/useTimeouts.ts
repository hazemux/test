import { useCallback, useEffect, useRef } from 'react';

/** setTimeout that is automatically cleared when the component unmounts. */
export function useTimeouts() {
  const ids = useRef<number[]>([]);

  useEffect(() => {
    const list = ids.current;
    return () => list.forEach((id) => window.clearTimeout(id));
  }, []);

  return useCallback((fn: () => void, ms: number) => {
    const id = window.setTimeout(fn, ms);
    ids.current.push(id);
    return id;
  }, []);
}