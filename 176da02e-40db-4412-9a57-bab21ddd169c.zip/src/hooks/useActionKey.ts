import { useEffect, useRef } from 'react';

/** Maps the Space key to the game's primary tap action while enabled. */
export function useActionKey(onAction: () => void, enabled: boolean) {
  const actionRef = useRef(onAction);
  actionRef.current = onAction;

  useEffect(() => {
    if (!enabled) return;
    const handler = (event: KeyboardEvent) => {
      if (event.code === 'Space' || event.key === ' ') {
        event.preventDefault();
        actionRef.current();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [enabled]);
}