import { useEffect, useRef } from 'react';

/** Runs callback every animation frame while `running`, passing ms elapsed since the loop started. */
export function useRafLoop(callback: (elapsed: number) => void, running: boolean) {
  const callbackRef = useRef(callback);
  callbackRef.current = callback;
  const startRef = useRef<number | null>(null);

  useEffect(() => {
    if (!running) return;
    let raf = 0;
    startRef.current = null;
    const tick = (now: number) => {
      if (startRef.current === null) startRef.current = now;
      callbackRef.current(now - startRef.current);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  return startRef;
}