import React, { memo, useMemo, useRef, useState } from 'react';
import { useRafLoop } from '../../hooks/useRafLoop';
import { useActionKey } from '../../hooks/useActionKey';
import { useTimeouts } from '../../hooks/useTimeouts';
import type { GameProps } from '../../types/game';

type AttackResult = 'perfect' | 'strong' | 'basic' | 'breach';
type Fx = {id: number;kind: 'block' | 'breach' | 'early';x: number;y: number;label: string;};

const LEAD_IN = 600;
const GAP = 650;
const DURATIONS = [1500, 1200, 950];
const SHIELD_R = 80;
const SPAWN_R = 232;
const WINDOW = { perfect: 80, strong: 160, basic: 270 };
const POINTS: Record<AttackResult, number> = { perfect: 10, strong: 6, basic: 3, breach: 0 };
const LABELS: Record<AttackResult, string> = { perfect: 'Perfect', strong: 'Strong', basic: 'Basic', breach: 'Breach' };
const STARTS = (() => {
  let t = LEAD_IN;
  return DURATIONS.map((d) => {
    const s = t;
    t += d + GAP;
    return s;
  });
})();
const END_AT = STARTS[2] + DURATIONS[2] + 450;
const DIRECTIONS = [0, 45, 90, 135, 180, 225, 270, 315];

export const ShieldReflex = memo(function ShieldReflex({ phase, onProgress, onComplete }: GameProps) {
  const angles = useMemo(pickAngles, []);
  const projRef = useRef<SVGGElement>(null);
  const resolvedRef = useRef<(AttackResult | null)[]>([null, null, null]);
  const attemptRef = useRef<boolean[]>([false, false, false]);
  const scoreRef = useRef(0);
  const fxId = useRef(0);
  const activeRef = useRef(-1);
  const finishedRef = useRef(false);
  const [results, setResults] = useState<(AttackResult | null)[]>([null, null, null]);
  const [active, setActive] = useState(-1);
  const [shieldKey, setShieldKey] = useState(0);
  const [fx, setFx] = useState<Fx | null>(null);
  const [finished, setFinished] = useState(false);
  const schedule = useTimeouts();
  const playing = phase === 'playing';

  const impactPoint = (i: number) => {
    const a = angles[i] * Math.PI / 180;
    return { x: Math.cos(a) * SHIELD_R, y: Math.sin(a) * SHIELD_R };
  };

  const settle = (i: number, res: AttackResult) => {
    resolvedRef.current[i] = res;
    setResults((prev) => {
      const next = [...prev];
      next[i] = res;
      return next;
    });
    scoreRef.current += POINTS[res];
    onProgress(scoreRef.current);
    const p = impactPoint(i);
    fxId.current += 1;
    setFx({
      id: fxId.current,
      kind: res === 'breach' ? 'breach' : 'block',
      x: p.x,
      y: p.y,
      label: res === 'breach' ? 'Core hit' : `${LABELS[res]} +${POINTS[res]}`
    });
  };

  const startRef = useRafLoop(
    (elapsed) => {
      let current = -1;
      for (let i = 0; i < 3; i++) {
        if (elapsed >= STARTS[i] && elapsed < STARTS[i] + DURATIONS[i]) current = i;
        if (resolvedRef.current[i] === null && elapsed >= STARTS[i] + DURATIONS[i]) settle(i, 'breach');
      }
      if (current !== activeRef.current) {
        activeRef.current = current;
        setActive(current);
      }
      const el = projRef.current;
      if (el) {
        if (current >= 0 && resolvedRef.current[current] === null) {
          const p = (elapsed - STARTS[current]) / DURATIONS[current];
          const r = SPAWN_R - (SPAWN_R - SHIELD_R) * p;
          const a = angles[current] * Math.PI / 180;
          el.setAttribute(
            'transform',
            `translate(${(Math.cos(a) * r).toFixed(2)} ${(Math.sin(a) * r).toFixed(2)}) rotate(${angles[current] + 180})`
          );
          el.style.opacity = '1';
        } else {
          el.style.opacity = '0';
        }
      }
      if (elapsed >= END_AT && !finishedRef.current) {
        finishedRef.current = true;
        setFinished(true);
        const blocked = resolvedRef.current.filter((r) => r && r !== 'breach').length;
        const perfects = resolvedRef.current.filter((r) => r === 'perfect').length;
        schedule(
          () =>
          onComplete({
            score: scoreRef.current,
            detail: `${blocked} of 3 attacks blocked${perfects ? ` · ${perfects} perfect` : ''}`
          }),
          350
        );
      }
    },
    playing && !finished
  );

  const tap = () => {
    if (!playing || finished) return;
    setShieldKey((k) => k + 1);
    const start = startRef.current;
    if (start === null) return;
    const elapsed = performance.now() - start;
    const i = [0, 1, 2].find((j) => elapsed >= STARTS[j] && elapsed < STARTS[j] + DURATIONS[j]);
    if (i === undefined || attemptRef.current[i] || resolvedRef.current[i] !== null) return;
    attemptRef.current[i] = true;
    const delta = STARTS[i] + DURATIONS[i] - elapsed;
    if (delta <= WINDOW.basic) {
      settle(i, delta <= WINDOW.perfect ? 'perfect' : delta <= WINDOW.strong ? 'strong' : 'basic');
    } else {
      fxId.current += 1;
      setFx({ id: fxId.current, kind: 'early', x: 0, y: 0, label: 'Too early' });
    }
  };
  useActionKey(tap, playing && !finished);

  const breached = fx?.kind === 'breach';

  return (
    <div
      className="absolute inset-0 cursor-pointer touch-none select-none bg-[#071A2C]"
      onPointerDown={tap}
      role="application"
      aria-label="Shield Reflex play field. Tap or press Space to raise the shield.">
      
      <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full" aria-hidden="true">
        <g transform="translate(200 200)">
          <g fill="none" stroke="#8ED3FF">
            <circle r="120" strokeOpacity="0.07" />
            <circle r="160" strokeOpacity="0.06" />
            <circle r="200" strokeOpacity="0.05" />
          </g>
          {DIRECTIONS.map((d) => {
            const a = d * Math.PI / 180;
            const isLane = active >= 0 && angles[active] === d;
            return (
              <line
                key={d}
                x1={Math.cos(a) * 96}
                y1={Math.sin(a) * 96}
                x2={Math.cos(a) * 240}
                y2={Math.sin(a) * 240}
                stroke={isLane ? '#FFBE32' : '#FFFFFF'}
                strokeOpacity={isLane ? 0.3 : 0.05}
                strokeDasharray={isLane ? '4 6' : undefined} />);


          })}

          <circle r={SHIELD_R + 7} fill="none" stroke="#FFBE32" strokeOpacity="0.1" strokeWidth="14" />
          <circle r={SHIELD_R} fill="none" stroke="#8ED3FF" strokeOpacity="0.45" strokeDasharray="3 5" />

          {shieldKey > 0 &&
          <g key={shieldKey} className="svg-center anim-shield">
              <polygon points={hexPoints(SHIELD_R + 6)} fill="#8ED3FF" fillOpacity="0.12" stroke="#8ED3FF" strokeWidth="5" />
              <polygon points={hexPoints(SHIELD_R - 4)} fill="none" stroke="#FFFFFF" strokeOpacity="0.5" strokeWidth="1" />
            </g>
          }

          <g key={breached ? fx?.id : 'core'} className={`svg-center ${breached ? 'anim-shake' : ''}`}>
            <g className={`svg-center anim-spin ${phase === 'done' ? 'paused' : ''}`}>
              <polygon points={hexPoints(54)} fill="none" stroke="#8ED3FF" strokeOpacity="0.35" strokeDasharray="10 6" />
            </g>
            <polygon points={hexPoints(40)} fill="#007BBF" />
            <polygon points={`0,-40 34.64,-20 0,0 -34.64,-20`} fill="#2A9AD8" />
            <polygon points={hexPoints(20)} fill="#0A2A44" />
            <circle r="8" fill="#FFBE32" className={`svg-center anim-breathe ${phase === 'done' ? 'paused' : ''}`} />
            {breached && <polygon key={fx?.id} points={hexPoints(40)} fill="#E8553E" className="anim-flash" />}
          </g>

          <g ref={projRef} style={{ opacity: 0 }}>
            <line x1="-12" y1="0" x2="-58" y2="0" stroke="#FFBE32" strokeOpacity="0.35" strokeWidth="3" strokeLinecap="round" />
            <polygon points="12,0 -4,-7 -10,0 -4,7" fill="#FFBE32" />
            <polygon points="12,0 -4,-7 -2,0" fill="#FFE29A" />
          </g>

          {fx && fx.kind === 'block' &&
          <circle key={fx.id} cx={fx.x} cy={fx.y} r="18" fill="none" stroke="#FFBE32" strokeWidth="4" className="svg-center anim-burst" />
          }
        </g>
      </svg>

      {fx &&
      <p
        key={fx.id}
        className="anim-rise pointer-events-none absolute inset-x-0 top-[9%] text-center font-display text-3xl font-bold"
        style={{ color: fx.kind === 'block' ? '#FFBE32' : fx.kind === 'breach' ? '#FF8F7D' : '#8ED3FF' }}>
        
          {fx.label}
        </p>
      }

      {phase !== 'ready' &&
      <ol className="pointer-events-none absolute inset-x-0 bottom-3 flex justify-center gap-1.5 px-3 sm:bottom-4 sm:gap-2">
          {results.map((res, i) =>
        <li
          key={i}
          className="flex h-8 items-center whitespace-nowrap rounded-full border px-2.5 text-[11px] font-semibold transition-colors duration-200 sm:px-3 sm:text-xs"
          style={pipStyle(res, active === i)}>
          
              {res ? res === 'breach' ? 'Breach' : `${LABELS[res]} +${POINTS[res]}` : `Attack ${i + 1}`}
            </li>
        )}
        </ol>
      }
    </div>);

});

function pickAngles(): number[] {
  const pool = [...DIRECTIONS];
  const out: number[] = [];
  while (out.length < 3) {
    const idx = Math.floor(Math.random() * pool.length);
    out.push(pool.splice(idx, 1)[0]);
  }
  return out;
}

function hexPoints(r: number): string {
  return Array.from({ length: 6 }, (_, k) => {
    const a = (-90 + k * 60) * Math.PI / 180;
    return `${(Math.cos(a) * r).toFixed(2)},${(Math.sin(a) * r).toFixed(2)}`;
  }).join(' ');
}

function pipStyle(res: AttackResult | null, current: boolean): React.CSSProperties {
  if (res === 'perfect') return { background: '#FFBE32', borderColor: '#FFBE32', color: '#0E1A24' };
  if (res === 'strong') return { background: '#8ED3FF', borderColor: '#8ED3FF', color: '#0E1A24' };
  if (res === 'basic') return { background: '#DCE7F0', borderColor: '#DCE7F0', color: '#0E1A24' };
  if (res === 'breach') return { background: 'rgba(232,85,62,0.18)', borderColor: 'rgba(232,85,62,0.6)', color: '#FFB3A6' };
  return current ?
  { borderColor: 'rgba(255,255,255,0.5)', color: '#FFFFFF' } :
  { borderColor: 'rgba(255,255,255,0.15)', color: 'rgba(255,255,255,0.55)' };
}