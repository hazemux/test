import React, { memo, useEffect, useRef, useState } from 'react';
import { useTimeouts } from '../../hooks/useTimeouts';
import type { GameProps } from '../../types/game';

interface Target {
  i: number;
  x: number;
  y: number;
  window: number;
  shownAt: number;
}

type Mark = {id: number;x: number;y: number;kind: 'hit' | 'miss';};

const APPEARANCES = 8;
const RING_LEN = 213.63;
const windowFor = (i: number) => 1150 - i * 90;

export const CoreFocus = memo(function CoreFocus({ phase, onProgress, onComplete }: GameProps) {
  const [target, setTarget] = useState<Target | null>(null);
  const [results, setResults] = useState<('hit' | 'miss' | null)[]>(() => Array(APPEARANCES).fill(null));
  const [mark, setMark] = useState<Mark | null>(null);
  const targetRef = useRef<Target | null>(null);
  const lastPos = useRef({ x: 50, y: 50 });
  const hitsRef = useRef(0);
  const reactions = useRef<number[]>([]);
  const markId = useRef(0);
  const schedule = useTimeouts();
  const callbacks = useRef({ onComplete, onProgress });
  callbacks.current = { onComplete, onProgress };

  const record = (i: number, res: 'hit' | 'miss') =>
  setResults((prev) => {
    const next = [...prev];
    next[i] = res;
    return next;
  });

  const finish = () => {
    const hits = hitsRef.current;
    const avg = reactions.current.length ?
    Math.round(reactions.current.reduce((a, b) => a + b, 0) / reactions.current.length) :
    0;
    schedule(
      () =>
      callbacks.current.onComplete({
        score: hits,
        detail: hits ? `${hits} of 8 caught · ${avg}ms average reaction` : 'The Core slipped away every time'
      }),
      450
    );
  };

  const show = (i: number) => {
    if (i >= APPEARANCES) {
      finish();
      return;
    }
    const pos = pickPosition(lastPos.current);
    lastPos.current = pos;
    const t: Target = { i, ...pos, window: windowFor(i), shownAt: performance.now() };
    targetRef.current = t;
    setTarget(t);
    schedule(() => {
      if (targetRef.current?.i !== i) return;
      targetRef.current = null;
      setTarget(null);
      record(i, 'miss');
      markId.current += 1;
      setMark({ id: markId.current, x: t.x, y: t.y, kind: 'miss' });
      schedule(() => show(i + 1), 260);
    }, t.window);
  };

  useEffect(() => {
    if (phase === 'playing') schedule(() => show(0), 450);
    // show is intentionally excluded: the run is started once per mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  const hit = () => {
    const t = targetRef.current;
    if (!t || phase !== 'playing') return;
    targetRef.current = null;
    reactions.current.push(performance.now() - t.shownAt);
    hitsRef.current += 1;
    callbacks.current.onProgress(hitsRef.current);
    record(t.i, 'hit');
    setTarget(null);
    markId.current += 1;
    setMark({ id: markId.current, x: t.x, y: t.y, kind: 'hit' });
    schedule(() => show(t.i + 1), 200);
  };

  const current = target?.i ?? results.findIndex((r) => r === null);

  return (
    <div className="dot-grid absolute inset-0 touch-none select-none overflow-hidden bg-cq-blue">
      <div aria-hidden="true" className="absolute inset-y-0 left-1/2 w-px bg-white/10" />
      <div aria-hidden="true" className="absolute inset-x-0 top-1/2 h-px bg-white/10" />

      {phase !== 'ready' &&
      <ol className="absolute inset-x-0 top-4 flex justify-center gap-1.5 px-6" aria-label="Appearances">
          {results.map((r, i) =>
        <li
          key={i}
          className={`h-1.5 w-6 rounded-full transition-colors duration-200 sm:w-8 ${
          r === 'hit' ? 'bg-cq-yellow' : r === 'miss' ? 'bg-[#00476F]' : i === current ? 'bg-white/70' : 'bg-white/25'}`
          }>
          
              <span className="sr-only">{r ?? 'pending'}</span>
            </li>
        )}
        </ol>
      }

      {phase === 'ready' &&
      <div className="anim-bob absolute left-1/2 top-[44%]">
          <FocusCore />
        </div>
      }

      {target &&
      <button
        key={target.i}
        type="button"
        onPointerDown={(e) => {
          e.stopPropagation();
          hit();
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            hit();
          }
        }}
        aria-label="Tap the Core"
        className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full outline-none focus-visible:ring-2 focus-visible:ring-white"
        style={{ left: `${target.x}%`, top: `${target.y}%` }}>
        
          <span className="anim-enter block">
            <FocusCore countdown={target.window} />
          </span>
        </button>
      }

      {mark &&
      <span
        key={mark.id}
        aria-hidden="true"
        className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2"
        style={{ left: `${mark.x}%`, top: `${mark.y}%` }}>
        
          <svg viewBox="-40 -40 80 80" width="80" height="80" className="anim-burst">
            <circle r="30" fill="none" stroke={mark.kind === 'hit' ? '#FFBE32' : '#00476F'} strokeWidth="6" />
          </svg>
        </span>
      }
    </div>);

});

function FocusCore({ countdown }: {countdown?: number;}) {
  return (
    <svg viewBox="-40 -40 80 80" width="80" height="80" aria-hidden="true">
      <circle r="34" fill="none" stroke="#FFFFFF" strokeOpacity="0.2" strokeWidth="3" />
      {countdown &&
      <circle
        r="34"
        fill="none"
        stroke="#FFFFFF"
        strokeWidth="3"
        strokeLinecap="round"
        transform="rotate(-90)"
        className="anim-countdown"
        style={{ ['--len' as string]: RING_LEN, ['--dur' as string]: `${countdown}ms` } as React.CSSProperties} />

      }
      <circle r="26" fill="#FFBE32" />
      <path d="M-26 0 A26 26 0 0 1 26 0Z" fill="#FFCB55" />
      <circle r="13" fill="#007BBF" />
      <circle r="4" cx="-3" cy="-3" fill="#FFFFFF" />
    </svg>);

}

function pickPosition(last: {x: number;y: number;}): {x: number;y: number;} {
  let pos = { x: 50, y: 50 };
  for (let n = 0; n < 10; n++) {
    pos = { x: 14 + Math.random() * 72, y: 20 + Math.random() * 64 };
    if (Math.hypot(pos.x - last.x, pos.y - last.y) > 26) return pos;
  }
  return pos;
}