import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import { useTimeouts } from '../../hooks/useTimeouts';
import type { GameProps } from '../../types/game';

type Mode = 'idle' | 'show' | 'input' | 'success' | 'fail';

const LENGTHS = [3, 4, 5];
const NODE_R = 130;
const SHOW_ON = 400;
const SHOW_STEP = 580;
const NODES = Array.from({ length: 6 }, (_, i) => {
  const a = (-90 + i * 60) * Math.PI / 180;
  return { x: Math.cos(a) * NODE_R, y: Math.sin(a) * NODE_R };
});

export const CoreSequence = memo(function CoreSequence({ phase, onProgress, onComplete }: GameProps) {
  const [seq] = useState(makeSequence);
  const [round, setRound] = useState(0);
  const [mode, setMode] = useState<Mode>('idle');
  const [lit, setLit] = useState<number | null>(null);
  const [inputIdx, setInputIdx] = useState(0);
  const [pressed, setPressed] = useState<{node: number;ok: boolean;id: number;} | null>(null);
  const pressId = useRef(0);
  const schedule = useTimeouts();

  const playRound = useCallback(
    (r: number) => {
      setMode('show');
      setInputIdx(0);
      const len = LENGTHS[r];
      for (let k = 0; k < len; k++) {
        schedule(() => setLit(seq[k]), 350 + k * SHOW_STEP);
        schedule(() => setLit(null), 350 + k * SHOW_STEP + SHOW_ON);
      }
      schedule(() => setMode('input'), 350 + len * SHOW_STEP - 120);
    },
    [schedule, seq]
  );

  useEffect(() => {
    if (phase === 'playing' && mode === 'idle') playRound(0);
  }, [phase, mode, playRound]);

  const press = (i: number) => {
    if (mode !== 'input' || phase !== 'playing') return;
    const ok = i === seq[inputIdx];
    pressId.current += 1;
    setPressed({ node: i, ok, id: pressId.current });
    if (!ok) {
      setMode('fail');
      schedule(
        () =>
        onComplete({
          score: round,
          detail: round === 0 ? 'The first pattern slipped away' : `Cleared ${round} of 3 sequences before a wrong node`
        }),
        950
      );
      return;
    }
    const next = inputIdx + 1;
    if (next === LENGTHS[round]) {
      setMode('success');
      onProgress(round + 1);
      if (round < 2) {
        schedule(() => {
          setRound(round + 1);
          playRound(round + 1);
        }, 700);
      } else {
        schedule(() => onComplete({ score: 3, detail: 'All three sequences recalled — 12 nodes in order' }), 800);
      }
    } else {
      setInputIdx(next);
    }
  };

  const status =
  mode === 'show' ?
  'Watch the Core' :
  mode === 'input' ?
  `Your turn · ${inputIdx}/${LENGTHS[round]}` :
  mode === 'success' ?
  'Sequence locked' :
  mode === 'fail' ?
  'Wrong node' :
  'Memorize, then repeat';

  return (
    <div className="absolute inset-0 select-none bg-[#0B0D10]">
      <div className="absolute inset-x-0 top-4 flex flex-col items-center gap-2.5">
        <p
          key={status}
          className={`anim-rise text-sm font-semibold ${
          mode === 'fail' ? 'text-[#FF8F7D]' : mode === 'success' ? 'text-cq-yellow' : 'text-white/80'}`
          }
          aria-live="polite">
          
          {status}
        </p>
        <div className="flex gap-1.5" aria-hidden="true">
          {LENGTHS.map((len, i) => {
            const cleared = i < round || i === round && mode === 'success';
            return (
              <span
                key={len}
                className={`h-1 w-10 rounded-full transition-colors duration-200 ${
                cleared ? 'bg-cq-yellow' : i === round && phase !== 'ready' ? 'bg-white/45' : 'bg-white/10'}`
                } />);


          })}
        </div>
      </div>

      <svg viewBox="0 0 400 400" className="absolute inset-x-0 bottom-[3%] top-[13%] h-[84%] w-full">
        <g transform="translate(200 200)">
          <polygon
            points={NODES.map((n) => `${n.x.toFixed(1)},${n.y.toFixed(1)}`).join(' ')}
            fill="none"
            stroke="#FFFFFF"
            strokeOpacity="0.06" />
          
          {NODES.map((n, i) =>
          <line
            key={i}
            x1={n.x * 0.36}
            y1={n.y * 0.36}
            x2={n.x * 0.76}
            y2={n.y * 0.76}
            stroke={lit === i ? '#FFBE32' : '#FFFFFF'}
            strokeOpacity={lit === i ? 0.7 : 0.08}
            strokeWidth="1.5" />

          )}

          <g aria-hidden="true">
            <g className={`svg-center anim-spin ${phase === 'done' ? 'paused' : ''}`}>
              <circle r="58" fill="none" stroke="#FFFFFF" strokeOpacity="0.16" strokeDasharray="22 14" />
            </g>
            <circle r="44" fill="#007BBF" />
            <path d="M-44 0 A44 44 0 0 1 44 0Z" fill="#1A8CCB" />
            <circle r="17" fill="#0B0D10" />
            <circle
              r="6"
              fill={mode === 'fail' ? '#E8553E' : '#FFBE32'}
              className={`svg-center ${mode === 'show' ? 'anim-breathe' : ''}`} />
            
          </g>

          {NODES.map((n, i) => {
            const isLit = lit === i;
            const disabled = mode !== 'input' || phase !== 'playing';
            return (
              <g
                key={i}
                transform={`translate(${n.x} ${n.y})`}
                role="button"
                tabIndex={disabled ? -1 : 0}
                aria-label={`Energy node ${i + 1}`}
                aria-disabled={disabled}
                onPointerDown={() => press(i)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    press(i);
                  }
                }}
                className={`outline-none ${disabled ? '' : 'cursor-pointer'}`}>
                
                <circle r="34" fill="transparent" />
                <circle
                  r="28"
                  fill={isLit ? '#FFBE32' : '#14181E'}
                  stroke={isLit ? '#FFBE32' : '#FFFFFF'}
                  strokeOpacity={isLit ? 1 : mode === 'input' ? 0.32 : 0.14}
                  strokeWidth="1.5"
                  style={{ transition: 'fill 120ms ease-out' }} />
                
                <circle r="9" fill={isLit ? '#FFFFFF' : '#FFFFFF'} fillOpacity={isLit ? 0.95 : 0.22} />
                {pressed?.node === i &&
                <circle
                  key={pressed.id}
                  r="28"
                  fill={pressed.ok ? '#007BBF' : '#E8553E'}
                  className="anim-flash" />

                }
              </g>);

          })}
        </g>
      </svg>
    </div>);

});

function makeSequence(): number[] {
  const s: number[] = [];
  while (s.length < 5) {
    const n = Math.floor(Math.random() * 6);
    if (n !== s[s.length - 1]) s.push(n);
  }
  return s;
}