import React, { memo, useEffect, useRef, useState } from 'react';
import { TimerIcon } from 'lucide-react';
import { useTimeouts } from '../../hooks/useTimeouts';
import { useRafLoop } from '../../hooks/useRafLoop';
import { useElementSize } from '../../hooks/useElementSize';
import { CatchFragment, type FragmentKind } from './CatchFragment';
import type { GameProps } from '../../types/game';

interface Fragment {
  id: number;
  kind: FragmentKind;
  x: number;
  y: number;
}

interface Floater {
  id: number;
  x: number;
  y: number;
  value: number;
}

interface Layout {
  w: number;
  h: number;
  frag: number;
  core: number;
  top: number;
  bottom: number;
}

const DURATION = 8000;
const SPAWN_EVERY = 340;
const MAX_ALIVE = 5;
const URGENT_AT = 3000;
const TIMER_LEN = 345.58;
const KIND_ORDER: FragmentKind[] = ['blue', 'gold', 'dark'];
const KINDS: Record<FragmentKind, {value: number;life: number;name: string;color: string;}> = {
  blue: { value: 10, life: 1300, name: 'Blue', color: '#007BBF' },
  gold: { value: 25, life: 950, name: 'Golden', color: '#9A6500' },
  dark: { value: -20, life: 1500, name: 'Dark', color: '#2A2747' }
};

export const EnergyCatch = memo(function EnergyCatch({ phase, onProgress, onComplete }: GameProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const size = useElementSize(rootRef);
  const layout = getLayout(size.width, size.height);
  const layoutRef = useRef(layout);
  layoutRef.current = layout;

  const [fragments, setFragments] = useState<Fragment[]>([]);
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const [score, setScore] = useState(0);
  const [ended, setEnded] = useState(false);
  const [urgent, setUrgent] = useState(false);
  const [pulse, setPulse] = useState<{id: number;color: string;} | null>(null);
  const [darkFlash, setDarkFlash] = useState(0);

  const fragsRef = useRef<Fragment[]>([]);
  const scoreRef = useRef(0);
  const statsRef = useRef({ good: 0, dark: 0 });
  const idRef = useRef(0);
  const timerRef = useRef<HTMLSpanElement>(null);
  const urgentRef = useRef(false);
  const schedule = useTimeouts();
  const callbacks = useRef({ onComplete });
  callbacks.current.onComplete = onComplete;

  const playing = phase === 'playing';

  useRafLoop(
    (elapsed) => {
      const remaining = Math.max(0, DURATION - elapsed);
      if (timerRef.current) timerRef.current.textContent = (remaining / 1000).toFixed(1);
      if (remaining <= URGENT_AT && !urgentRef.current) {
        urgentRef.current = true;
        setUrgent(true);
      }
    },
    playing && !ended
  );

  useEffect(() => {
    if (phase !== 'playing') return;
    const timers: number[] = [];
    const sync = () => setFragments([...fragsRef.current]);

    const spawn = () => {
      if (fragsRef.current.length >= MAX_ALIVE) return;
      const kind = pickKind();
      idRef.current += 1;
      const frag: Fragment = { id: idRef.current, kind, ...pickPosition(fragsRef.current, layoutRef.current) };
      fragsRef.current = [...fragsRef.current, frag];
      sync();
      timers.push(
        window.setTimeout(() => {
          fragsRef.current = fragsRef.current.filter((f) => f.id !== frag.id);
          sync();
        }, KINDS[kind].life)
      );
    };

    spawn();
    const interval = window.setInterval(spawn, SPAWN_EVERY);
    const end = window.setTimeout(() => {
      window.clearInterval(interval);
      fragsRef.current = [];
      sync();
      setEnded(true);
      if (timerRef.current) timerRef.current.textContent = '0.0';
      const { good, dark } = statsRef.current;
      timers.push(
        window.setTimeout(
          () =>
          callbacks.current.onComplete({
            score: scoreRef.current,
            detail: `${good} fragments caught · ${dark} dark ${dark === 1 ? 'hit' : 'hits'}`
          }),
          700
        )
      );
    }, DURATION);

    return () => {
      window.clearInterval(interval);
      window.clearTimeout(end);
      timers.forEach((t) => window.clearTimeout(t));
    };
  }, [phase]);

  const collect = (frag: Fragment) => {
    if (!playing || ended) return;
    if (!fragsRef.current.some((f) => f.id === frag.id)) return;
    fragsRef.current = fragsRef.current.filter((f) => f.id !== frag.id);
    setFragments([...fragsRef.current]);

    const { value, color } = KINDS[frag.kind];
    if (frag.kind === 'dark') {
      statsRef.current.dark += 1;
      setDarkFlash((n) => n + 1);
    } else {
      statsRef.current.good += 1;
    }
    scoreRef.current = Math.max(0, scoreRef.current + value);
    setScore(scoreRef.current);
    onProgress(scoreRef.current);
    setPulse({ id: frag.id, color });

    const floater = { id: frag.id, x: frag.x, y: frag.y, value };
    setFloaters((prev) => [...prev, floater]);
    schedule(() => setFloaters((prev) => prev.filter((f) => f.id !== floater.id)), 700);
  };

  return (
    <div ref={rootRef} className="absolute inset-0 touch-none select-none overflow-hidden bg-[#FFF1C9]">
      <Backdrop />

      {phase === 'ready' ?
      <ReadyView core={layout.core} /> :

      <>
          {/* Timer */}
          <div className="pointer-events-none absolute inset-x-0 top-3 z-10 flex justify-center">
            <div
            className={`flex h-9 items-center gap-1.5 rounded-full px-3.5 text-sm font-bold tabular-nums shadow-[0_2px_0_rgba(154,101,0,0.15)] transition-colors duration-200 ${
            urgent ? 'bg-coral text-white' : 'bg-white text-ink'}`
            }>
            
              <TimerIcon className="h-4 w-4" aria-hidden="true" />
              <span ref={timerRef} className="w-7 text-right">
                {(DURATION / 1000).toFixed(1)}
              </span>
              <span className="font-semibold opacity-70">s</span>
            </div>
          </div>

          {/* Orbit guide */}
          <div
          aria-hidden="true"
          className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-dashed border-[#E8A100]/30"
          style={{ width: layout.core * 1.75, height: layout.core * 1.75 }} />
        

          {/* Core */}
          <div
          className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ width: layout.core, height: layout.core }}>
          
            {pulse &&
          <span
            key={pulse.id}
            aria-hidden="true"
            className="anim-burst absolute inset-0 rounded-full border-[6px]"
            style={{ borderColor: pulse.color }} />

          }
            <CoreBody urgent={urgent} running={playing && !ended} />
            <p className="absolute inset-0 flex flex-col items-center justify-center text-white" aria-live="polite">
              <span
              key={score}
              className="anim-enter font-display font-extrabold leading-none tabular-nums"
              style={{ fontSize: Math.round(layout.core * 0.24) }}>
              
                {score}
              </span>
              <span className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-white/75">points</span>
            </p>
          </div>

          {/* Fragments */}
          {fragments.map((f) =>
        <button
          key={f.id}
          type="button"
          onPointerDown={(e) => {
            e.stopPropagation();
            collect(f);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              collect(f);
            }
          }}
          aria-label={`${KINDS[f.kind].name} energy, ${formatValue(KINDS[f.kind].value)} points`}
          className="absolute z-[5] flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full outline-none focus-visible:ring-2 focus-visible:ring-cq-blue"
          style={{ left: `${f.x}%`, top: `${f.y}%`, width: layout.frag + 10, height: layout.frag + 10 }}>
          
              <span className="anim-enter block">
                <CatchFragment kind={f.kind} life={KINDS[f.kind].life} size={layout.frag} />
              </span>
            </button>
        )}

          {/* Floating score */}
          {floaters.map((f) =>
        <span
          key={f.id}
          className="anim-float pointer-events-none absolute z-[6] whitespace-nowrap rounded-full bg-white px-2 py-0.5 font-display text-lg font-extrabold tabular-nums shadow-[0_2px_0_rgba(14,26,36,0.08)]"
          style={{ left: `${f.x}%`, top: `${f.y}%`, color: KINDS[valueKind(f.value)].color }}>
          
              {formatValue(f.value)}
            </span>
        )}

          {/* Dark hit flash */}
          {darkFlash > 0 &&
        <div key={darkFlash} aria-hidden="true" className="anim-flash pointer-events-none absolute inset-0 z-[4] bg-[#2A2747]/15" />
        }

          {/* Legend */}
          <ul className="pointer-events-none absolute inset-x-0 bottom-3 z-10 mx-auto flex h-10 w-fit items-center gap-4 rounded-full bg-white/80 px-4 text-sm font-bold tabular-nums">
            {KIND_ORDER.map((k) =>
          <li key={k} className="flex items-center gap-1" style={{ color: KINDS[k].color }}>
                <CatchFragment kind={k} size={22} showLife={false} />
                {formatValue(KINDS[k].value)}
              </li>
          )}
          </ul>

          {ended &&
        <div className="pointer-events-none absolute inset-x-0 top-[18%] z-20 flex justify-center">
              <p className="anim-enter rounded-full bg-ink px-5 py-2 font-display text-xl font-bold text-white">Time's up</p>
            </div>
        }
        </>
      }
    </div>);

});

function Backdrop() {
  return (
    <svg
      viewBox="0 0 400 400"
      preserveAspectRatio="xMidYMid slice"
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden="true">
      
      <circle cx="200" cy="200" r="260" fill="#FFE9B0" />
      <circle cx="200" cy="200" r="180" fill="#FFE29A" />
      <circle cx="200" cy="200" r="104" fill="#FFDB85" />
    </svg>);

}

function CoreBody({ urgent, running }: {urgent: boolean;running: boolean;}) {
  return (
    <svg viewBox="-64 -64 128 128" className="h-full w-full" aria-hidden="true">
      <circle r="58" fill="#FFFFFF" fillOpacity="0.55" />
      <circle r="55" fill="none" stroke="#007BBF" strokeOpacity="0.14" strokeWidth="6" />
      {running &&
      <circle
        r="55"
        fill="none"
        stroke={urgent ? '#E8553E' : '#007BBF'}
        strokeWidth="6"
        strokeLinecap="round"
        transform="rotate(-90)"
        className="anim-countdown"
        style={{ ['--len' as string]: TIMER_LEN, ['--dur' as string]: `${DURATION}ms`, transition: 'stroke 200ms ease-out' } as React.CSSProperties} />

      }
      <circle r="44" fill="#007BBF" />
      <path d="M-44 0 A44 44 0 0 1 44 0Z" fill="#1A8CCB" />
      <circle r="32" fill="#00609A" />
      <circle r="4" cx="-16" cy="-24" fill="#FFFFFF" opacity="0.6" />
    </svg>);

}

function ReadyView({ core }: {core: number;}) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 px-4 pb-24 pt-4">
      <div className="relative" style={{ width: core, height: core }}>
        <div className="anim-bob absolute left-1/2 top-1/2 h-full w-full">
          <CoreBody urgent={false} running={false} />
          <p className="absolute inset-0 flex flex-col items-center justify-center text-white">
            <span className="font-display font-extrabold leading-none" style={{ fontSize: Math.round(core * 0.22) }}>
              8s
            </span>
            <span className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-white/75">to catch</span>
          </p>
        </div>
      </div>

      <ul className="grid w-full max-w-[360px] grid-cols-3 gap-2" aria-label="Fragment values">
        {KIND_ORDER.map((k) =>
        <li key={k} className="flex flex-col items-center rounded-2xl bg-white/75 px-2 pb-2.5 pt-2">
            <CatchFragment kind={k} size={40} showLife={false} />
            <span className="mt-0.5 font-display text-lg font-extrabold tabular-nums" style={{ color: KINDS[k].color }}>
              {formatValue(KINDS[k].value)}
            </span>
            <span className="whitespace-nowrap text-[11px] font-medium text-ink/60">{KINDS[k].name} energy</span>
          </li>
        )}
      </ul>
    </div>);

}

function getLayout(w: number, h: number): Layout {
  const min = Math.min(w, h) || 360;
  return {
    w: w || 360,
    h: h || 450,
    frag: clamp(min * 0.15, 50, 68),
    core: clamp(min * 0.3, 104, 150),
    top: 56,
    bottom: 60
  };
}

function pickPosition(existing: Fragment[], L: Layout): {x: number;y: number;} {
  const r = (L.frag + 10) / 2 + 4;
  const minY = L.top + r;
  const maxY = L.h - L.bottom - r;
  const coreClear = L.core / 2 + r + 8;
  let fallback = { x: 25, y: 30 };

  for (let n = 0; n < 16; n++) {
    const x = r + Math.random() * Math.max(1, L.w - r * 2);
    const y = minY + Math.random() * Math.max(1, maxY - minY);
    if (Math.hypot(x - L.w / 2, y - L.h / 2) < coreClear) continue;
    const pos = { x: x / L.w * 100, y: y / L.h * 100 };
    fallback = pos;
    const free = existing.every((f) => Math.hypot(f.x / 100 * L.w - x, f.y / 100 * L.h - y) > L.frag * 1.15);
    if (free) return pos;
  }
  return fallback;
}

function pickKind(): FragmentKind {
  const r = Math.random();
  if (r < 0.55) return 'blue';
  if (r < 0.73) return 'gold';
  return 'dark';
}

function valueKind(value: number): FragmentKind {
  if (value < 0) return 'dark';
  return value > 10 ? 'gold' : 'blue';
}

function formatValue(value: number): string {
  return value > 0 ? `+${value}` : `−${Math.abs(value)}`;
}

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}