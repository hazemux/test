import React, { memo, useMemo, useRef, useState } from 'react';
import { CheckIcon, XIcon } from 'lucide-react';
import { useRafLoop } from '../../hooks/useRafLoop';
import { useActionKey } from '../../hooks/useActionKey';
import { useTimeouts } from '../../hooks/useTimeouts';
import { EnergyCanister } from './EnergyCanister';
import type { GameProps } from '../../types/game';

const ROUNDS = [
{ width: 26, period: 1400, name: 'Wide' },
{ width: 16, period: 1150, name: 'Narrow' },
{ width: 9, period: 900, name: 'Razor' }];


export const EnergyBalance = memo(function EnergyBalance({ phase, onProgress, onComplete }: GameProps) {
  const zones = useMemo(() => ROUNDS.map((r) => 8 + Math.random() * (84 - r.width)), []);
  const [round, setRound] = useState(0);
  const [stopped, setStopped] = useState<{pos: number;hit: boolean;id: number;} | null>(null);
  const [results, setResults] = useState<boolean[]>([]);
  const posRef = useRef(0);
  const indRef = useRef<HTMLDivElement>(null);
  const schedule = useTimeouts();
  const playing = phase === 'playing';
  const hits = results.filter(Boolean).length;

  useRafLoop(
    (elapsed) => {
      const { period } = ROUNDS[round];
      const cycle = elapsed / period % 2;
      const p = (cycle < 1 ? cycle : 2 - cycle) * 100;
      posRef.current = p;
      if (indRef.current) indRef.current.style.transform = `translateX(${p}%)`;
    },
    playing && !stopped && results.length < 3
  );

  const tap = () => {
    if (!playing || stopped || results.length >= 3) return;
    const p = posRef.current;
    const z = zones[round];
    const hit = p >= z && p <= z + ROUNDS[round].width;
    const next = [...results, hit];
    const total = next.filter(Boolean).length;
    setStopped({ pos: p, hit, id: round });
    setResults(next);
    onProgress(total);
    schedule(() => {
      if (round < 2) {
        setRound(round + 1);
        setStopped(null);
      } else {
        onComplete({
          score: total,
          detail: total === 3 ? 'Every stop landed — even the razor zone' : `${total} of 3 stops landed in the zone`
        });
      }
    }, 800);
  };
  useActionKey(tap, playing && !stopped);

  const zone = zones[round];
  const width = ROUNDS[round].width;
  const puckColor = stopped ? stopped.hit ? '#E8A100' : '#E8553E' : '#007BBF';

  return (
    <div
      className="absolute inset-0 flex cursor-pointer touch-none select-none flex-col items-center justify-center gap-[5%] bg-[#E2EDF5] px-4 pb-20 pt-4 sm:px-5 sm:pb-6"
      onPointerDown={tap}
      role="application"
      aria-label="Energy Balance play field. Tap or press Space to stop the indicator.">
      
      <div aria-hidden="true" className="absolute inset-x-0 bottom-0 h-[42%] bg-[#D4E4EF]" />

      <div className="relative flex h-[34%] max-h-[210px] w-full justify-center">
        <EnergyCanister level={hits / 3} idle={phase !== 'done'} />
      </div>

      <div className="relative w-full max-w-[520px]">
        <div aria-hidden="true" className="absolute inset-x-0 top-2 h-full rounded-[28px] bg-[#A9C7DC]" />
        <div
          key={stopped && !stopped.hit ? `miss-${stopped.id}` : 'meter'}
          className={`relative rounded-[28px] bg-white p-3 ${stopped && !stopped.hit ? 'anim-shake' : ''}`}>
          
          <div className="relative h-14 rounded-[20px] bg-[#EAF2F8]">
            <div
              className="absolute inset-y-0 rounded-[12px] bg-cq-yellow/80 transition-[left,width] duration-300"
              style={{ left: `${zone}%`, width: `${width}%`, transitionTimingFunction: 'cubic-bezier(0.23,1,0.32,1)' }}>
              
              <div className="absolute inset-y-2 left-1/2 w-px bg-cq-amber" />
            </div>
            {stopped?.hit &&
            <div
              key={`hit-${stopped.id}`}
              className="anim-flash absolute inset-y-0 rounded-[12px] bg-cq-yellow"
              style={{ left: `${zone}%`, width: `${width}%` }} />

            }
            <div ref={indRef} className="pointer-events-none absolute inset-0" style={{ transform: 'translateX(0%)' }}>
              <div
                className="absolute -bottom-1.5 -top-1.5 left-0 -ml-2 w-4 rounded-full transition-colors duration-150"
                style={{ background: puckColor, boxShadow: '0 4px 0 rgba(14,26,36,0.18)' }}>
                
                <div className="absolute left-1 top-1.5 h-4 w-1 rounded-full bg-white/60" />
              </div>
            </div>
          </div>
          <div className="mt-2 flex justify-between px-1" aria-hidden="true">
            {Array.from({ length: 11 }, (_, i) =>
            <span key={i} className={`w-px bg-ink/20 ${i % 5 === 0 ? 'h-2.5' : 'h-1.5'}`} />
            )}
          </div>
        </div>
      </div>

      {phase !== 'ready' &&
      <ol className="relative flex gap-1.5 sm:gap-2">
          {ROUNDS.map((r, i) => {
          const res = results[i];
          const current = i === round && res === undefined;
          return (
            <li
              key={r.name}
              className={`flex h-9 items-center gap-1 whitespace-nowrap rounded-full px-2.5 text-[11px] font-semibold transition-colors duration-200 sm:gap-1.5 sm:px-3 sm:text-xs ${
              res === true ?
              'bg-cq-yellow text-ink' :
              res === false ?
              'bg-white text-coral' :
              current ?
              'bg-white text-ink ring-2 ring-cq-blue' :
              'bg-white/60 text-ink/50'}`
              }>
              
                {res === true && <CheckIcon className="h-3.5 w-3.5" />}
                {res === false && <XIcon className="h-3.5 w-3.5" />}
                {r.name}
                <span className="hidden sm:inline">· {r.width}%</span>
              </li>);

        })}
        </ol>
      }
    </div>);

});