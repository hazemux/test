import React from 'react';

export type FragmentKind = 'blue' | 'gold' | 'dark';

const RING_LEN = 157.08;

interface CatchFragmentProps {
  kind: FragmentKind;
  life?: number;
  size?: number;
  showLife?: boolean;
}

export function CatchFragment({ kind, life = 1000, size = 56, showLife = true }: CatchFragmentProps) {
  const ring = kind === 'blue' ? '#007BBF' : kind === 'gold' ? '#9A6500' : '#2A2747';

  return (
    <svg viewBox="-28 -28 56 56" width={size} height={size} aria-hidden="true">
      {showLife &&
      <>
          <circle r="25" fill="none" stroke={ring} strokeOpacity="0.12" strokeWidth="2.5" />
          <circle
          r="25"
          fill="none"
          stroke={ring}
          strokeOpacity="0.55"
          strokeWidth="2.5"
          transform="rotate(-90)"
          className="anim-countdown"
          style={{ ['--len' as string]: RING_LEN, ['--dur' as string]: `${life}ms` } as React.CSSProperties} />
        
        </>
      }
      {kind === 'blue' &&
      <g>
          <polygon points="0,-17 14.7,-8.5 14.7,8.5 0,17 -14.7,8.5 -14.7,-8.5" fill="#007BBF" />
          <polygon points="0,-17 14.7,-8.5 0,0 -14.7,-8.5" fill="#3AA6E0" />
          <polygon points="0,0 14.7,-8.5 14.7,8.5 0,17" fill="#0068A3" />
          <circle r="3" cx="-5" cy="-8" fill="#FFFFFF" opacity="0.8" />
        </g>
      }
      {kind === 'gold' &&
      <g>
          <path d="M0 -19 L5.5 -5.5 L19 0 L5.5 5.5 L0 19 L-5.5 5.5 L-19 0 L-5.5 -5.5Z" fill="#F5A400" stroke="#9A6500" strokeWidth="1.5" strokeLinejoin="round" />
          <path d="M0 -19 L5.5 -5.5 L0 0 L-5.5 -5.5Z" fill="#FFD777" />
          <path d="M19 0 L5.5 5.5 L0 0 L5.5 -5.5Z" fill="#FFC23D" />
          <circle r="3.5" fill="#FFFFFF" />
        </g>
      }
      {kind === 'dark' &&
      <g>
          <path
          d="M0 -19 L4 -10 L13.4 -13.4 L10 -4 L19 0 L10 4 L13.4 13.4 L4 10 L0 19 L-4 10 L-13.4 13.4 L-10 4 L-19 0 L-10 -4 L-13.4 -13.4 L-4 -10Z"
          fill="#2A2747" />
        
          <circle r="9" fill="#1A1830" />
          <circle r="4" fill="#A78BFA" />
        </g>
      }
    </svg>);

}