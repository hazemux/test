import React, { memo, useCallback, useRef, useState } from 'react';
import { useRafLoop } from '../../hooks/useRafLoop';
import { useActionKey } from '../../hooks/useActionKey';
import { useTimeouts } from '../../hooks/useTimeouts';
import type { GameProps } from '../../types/game';

type Outcome = {accuracy: number;label: string;radius: number;};

const TARGET = 112;
const ZONE = 18;
const GOOD = ZONE * Math.pow(0.4, 2 / 3);
const PERFECT = ZONE * Math.pow(0.1, 2 / 3);
const START_R = 194;
const CORE_EDGE = 54;
const DURATION = 1900;
const TICKS = Array.from({ length: 72 }, (_, i) => i);

export const PerfectPulse = memo(function PerfectPulse({ phase, onProgress, onComplete }: GameProps) {
  const ringRef = useRef<SVGCircleElement>(null);
  const radiusRef = useRef(START_R);
  const doneRef = useRef(false);
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const schedule = useTimeouts();
  const playing = phase === 'playing';

  const resolve = useCallback(
    (radius: number, missed: boolean) => {
      if (doneRef.current) return;
      doneRef.current = true;
      const accuracy = missed ? 0 : accuracyAt(radius);
      const label = missed ? 'Missed' : labelFor(accuracy, radius);
      setOutcome({ accuracy, label, radius });
      onProgress(accuracy);
      const detail =
      accuracy > 0 ?
      `${label} pulse at ${accuracy}% accuracy` :
      missed ?
      'The ring reached the Core untouched' :
      `${label} — the pulse fired outside the band`;
      schedule(() => onComplete({ score: accuracy, detail }), 950);
    },
    [onComplete, onProgress, schedule]
  );

  useRafLoop(
    (elapsed) => {
      const t = Math.min(elapsed / DURATION, 1);
      const r = START_R - (START_R - CORE_EDGE) * t;
      radiusRef.current = r;
      const el = ringRef.current;
      if (el) {
        el.setAttribute('r', r.toFixed(2));
        const d = Math.abs(r - TARGET);
        el.setAttribute('stroke', d <= PERFECT ? '#C98A00' : d <= ZONE ? '#2F8FC9' : '#007BBF');
      }
      if (t >= 1) resolve(r, true);
    },
    playing && !outcome
  );

  const tap = () => {
    if (!playing || doneRef.current) return;
    resolve(radiusRef.current, false);
  };
  useActionKey(tap, playing && !outcome);

  const hit = outcome !== null && outcome.accuracy > 0;
  const labelColor = !outcome ? '' : outcome.accuracy >= 90 ? '#9A6500' : outcome.accuracy > 0 ? '#007BBF' : '#C2412D';

  return (
    <div
      className="absolute inset-0 cursor-pointer touch-none select-none bg-[#F3EFE6]"
      onPointerDown={tap}
      role="application"
      aria-label="Perfect Pulse play field. Tap or press Space to fire the pulse.">
      
      <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full" aria-hidden="true">
        <g transform="translate(200 200)">
          <g fill="none" stroke="#007BBF">
            <circle r="186" strokeOpacity="0.12" />
            <circle r="150" strokeOpacity="0.1" strokeDasharray="2 6" />
            <circle r="76" strokeOpacity="0.14" />
            <line x1="-200" y1="0" x2="-160" y2="0" strokeOpacity="0.16" />
            <line x1="160" y1="0" x2="200" y2="0" strokeOpacity="0.16" />
            <line x1="0" y1="-200" x2="0" y2="-160" strokeOpacity="0.16" />
            <line x1="0" y1="160" x2="0" y2="200" strokeOpacity="0.16" />
          </g>
          <g stroke="#0E1A24" strokeOpacity="0.2">
            {TICKS.map((i) => {
              const a = i * 5 * Math.PI / 180;
              const r1 = i % 6 === 0 ? 172 : 178;
              return (
                <line
                  key={i}
                  x1={Math.cos(a) * r1}
                  y1={Math.sin(a) * r1}
                  x2={Math.cos(a) * 184}
                  y2={Math.sin(a) * 184} />);


            })}
          </g>

          <circle r={TARGET} fill="none" stroke="#FFBE32" strokeOpacity="0.24" strokeWidth={ZONE * 2} />
          <circle r={TARGET} fill="none" stroke="#FFBE32" strokeOpacity="0.55" strokeWidth={GOOD * 2} />
          <circle r={TARGET} fill="none" stroke="#E8A100" strokeWidth={PERFECT * 2} />

          <g className={`svg-center ${outcome && !hit ? 'anim-shake' : ''}`}>
            <g className={`svg-center anim-spin ${phase === 'done' ? 'paused' : ''}`}>
              <circle r="64" fill="none" stroke="#007BBF" strokeWidth="1.5" strokeDasharray="3 7" />
            </g>
            <g className={`svg-center anim-breathe ${phase === 'done' ? 'paused' : ''}`}>
              <circle r="48" fill="#007BBF" />
              <path d="M0 -48 A48 48 0 0 1 41.57 24 L0 0Z" fill="#1E90CF" />
              <path d="M0 -48 A48 48 0 0 0 -41.57 24 L0 0Z" fill="#006AA5" />
              <circle r="22" fill="#F3EFE6" />
              <circle r="13" fill="#FFBE32" />
              <circle r="4" cx="-4" cy="-4" fill="#FFFFFF" opacity="0.7" />
            </g>
          </g>

          <circle
            ref={ringRef}
            r={START_R}
            fill="none"
            stroke="#007BBF"
            strokeWidth="3.5"
            opacity={phase === 'ready' ? 0.35 : 1} />
          

          {hit && outcome &&
          <>
              <circle
              r={outcome.radius}
              fill="none"
              stroke={outcome.accuracy >= 90 ? '#FFBE32' : '#007BBF'}
              strokeWidth="10"
              className="svg-center anim-burst" />
            
              <circle r="48" fill="#FFBE32" className="svg-center anim-burst" />
            </>
          }
        </g>
      </svg>

      <div className="pointer-events-none absolute inset-x-0 top-4 flex justify-center gap-4 text-[11px] font-semibold text-ink/65">
        <span className="flex items-center gap-1.5">
          <i className="h-2 w-4 rounded-full bg-[#FFBE32]/30" /> Hit
        </span>
        <span className="flex items-center gap-1.5">
          <i className="h-2 w-4 rounded-full bg-[#FFBE32]/70" /> Good
        </span>
        <span className="flex items-center gap-1.5">
          <i className="h-2 w-4 rounded-full bg-cq-amber" /> Perfect
        </span>
      </div>

      {outcome &&
      <div className="anim-rise pointer-events-none absolute inset-x-0 bottom-[7%] text-center">
          <p className="font-display text-4xl font-extrabold" style={{ color: labelColor }}>
            {outcome.label}
          </p>
          <p className="mt-1 text-sm font-semibold tabular-nums text-ink/60">{outcome.accuracy}% accuracy</p>
        </div>
      }
    </div>);

});

function accuracyAt(r: number): number {
  const d = Math.abs(r - TARGET);
  if (d > ZONE) return 0;
  return Math.max(1, Math.round(100 * (1 - Math.pow(d / ZONE, 1.5))));
}

function labelFor(accuracy: number, r: number): string {
  if (accuracy >= 90) return 'Perfect';
  if (accuracy >= 60) return 'Good';
  if (accuracy > 0) return 'Hit';
  return r > TARGET ? 'Too early' : 'Too late';
}