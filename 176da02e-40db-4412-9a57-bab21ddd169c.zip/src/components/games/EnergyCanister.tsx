import React from 'react';

interface EnergyCanisterProps {
  level: number;
  idle: boolean;
}

export function EnergyCanister({ level, idle }: EnergyCanisterProps) {
  const fillOffset = (1 - level) * 104;

  return (
    <svg viewBox="0 0 180 200" className="h-full w-auto" aria-hidden="true">
      <defs>
        <linearGradient id="cq-glass" x1="0" x2="1">
          <stop offset="0" stopColor="#FFFFFF" />
          <stop offset="0.6" stopColor="#F2F8FC" />
          <stop offset="1" stopColor="#D9E8F2" />
        </linearGradient>
        <linearGradient id="cq-liquid" x1="0" x2="1">
          <stop offset="0" stopColor="#1E90CF" />
          <stop offset="0.55" stopColor="#007BBF" />
          <stop offset="1" stopColor="#005F94" />
        </linearGradient>
        <linearGradient id="cq-lid" x1="0" x2="1">
          <stop offset="0" stopColor="#FFCB55" />
          <stop offset="1" stopColor="#E8A100" />
        </linearGradient>
        <clipPath id="cq-glass-clip">
          <rect x="52" y="44" width="76" height="112" rx="10" />
        </clipPath>
      </defs>

      <ellipse cx="90" cy="186" rx="72" ry="10" fill="#0E1A24" opacity="0.08" />
      <ellipse cx="90" cy="172" rx="66" ry="15" fill="#A9C7DC" />
      <rect x="24" y="158" width="132" height="14" fill="#BCD5E6" />
      <ellipse cx="90" cy="158" rx="66" ry="15" fill="#EEF5FA" />
      <ellipse cx="90" cy="158" rx="44" ry="9" fill="#D7E7F2" />

      <rect x="52" y="44" width="76" height="112" rx="10" fill="url(#cq-glass)" />
      <g clipPath="url(#cq-glass-clip)">
        <g style={{ transform: `translateY(${fillOffset}px)`, transition: 'transform 300ms cubic-bezier(0.23,1,0.32,1)' }}>
          <rect x="52" y="52" width="76" height="110" fill="url(#cq-liquid)" />
          <ellipse cx="90" cy="52" rx="38" ry="6" fill="#4FB3E8" />
        </g>
      </g>
      <rect x="60" y="54" width="7" height="92" rx="3.5" fill="#FFFFFF" opacity="0.55" />
      {[1, 2].map((k) =>
      <line key={k} x1="116" x2="128" y1={156 - k * 35} y2={156 - k * 35} stroke="#0E1A24" strokeOpacity="0.18" strokeWidth="2" />
      )}
      <rect x="52" y="44" width="76" height="112" rx="10" fill="none" stroke="#0E1A24" strokeOpacity="0.1" strokeWidth="2" />

      <rect x="56" y="28" width="68" height="18" rx="4" fill="url(#cq-lid)" />
      <ellipse cx="90" cy="28" rx="34" ry="7" fill="#FFD777" />
      <g className={idle ? 'svg-center anim-breathe' : 'svg-center'}>
        <circle cx="90" cy="27" r="5" fill="#007BBF" />
      </g>
    </svg>);

}