import React, { useEffect, useRef } from 'react';
import { ArrowRightIcon, RotateCcwIcon } from 'lucide-react';
import { MedalBadge } from './MedalBadge';
import { medalStyles } from '../../data/medals';
import { useCountUp } from '../../hooks/useCountUp';
import { achievedTierIndex, formatScore } from '../../utils/rewards';
import type { GameMeta, GameResult } from '../../types/game';

interface RewardRevealProps {
  meta: GameMeta;
  result: GameResult;
  nextName: string;
  onReplay: () => void;
  onNext: () => void;
}

const RAYS = Array.from({ length: 8 }, (_, i) => i);

export function RewardReveal({ meta, result, nextName, onReplay, onNext }: RewardRevealProps) {
  const idx = achievedTierIndex(result.score, meta.tiers);
  const tier = idx >= 0 ? meta.tiers[idx] : null;
  const next = meta.tiers[idx + 1];
  const style = tier ? medalStyles[tier.medal] : null;
  const points = useCountUp(tier?.points ?? 0);
  const replayRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    replayRef.current?.focus({ preventScroll: true });
  }, []);

  return (
    <div className="anim-fade absolute inset-0 z-20 flex overflow-y-auto overscroll-contain bg-ink/60 p-3 sm:p-4">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="reveal-title"
        className="anim-enter m-auto w-full max-w-[360px] rounded-[28px] bg-white p-5 text-center shadow-[0_24px_60px_-20px_rgba(14,26,36,0.5)] sm:p-6">
        
        <div className="relative mx-auto flex h-20 w-20 items-center justify-center">
          {style &&
          RAYS.map((i) =>
          <span
            key={i}
            aria-hidden="true"
            className="absolute left-1/2 top-1/2 -ml-[2px] -mt-[6px] h-3 w-1"
            style={{ transform: `rotate(${i * 45}deg) translateY(-50px)` }}>
            
                <span className="anim-ray block h-full w-full rounded-full" style={{ background: style.fill }} />
              </span>
          )}
          {tier ?
          <MedalBadge medal={tier.medal} size={76} className="anim-medal" /> :

          <MedalBadge medal="bronze" size={76} muted className="anim-enter" />
          }
        </div>

        <p className="mt-3 text-[13px] font-semibold" style={{ color: style ? style.deep : 'rgba(14,26,36,0.55)' }}>
          {style ? `${style.name} reward unlocked` : 'No reward this round'}
        </p>
        <h3 id="reveal-title" className="font-display text-2xl font-bold text-ink">
          {tier ? tier.label : 'So close'}
        </h3>
        <p className="mt-1 text-sm text-ink/60">{result.detail}</p>

        <div className="mt-4 rounded-2xl bg-paper px-4 py-3">
          <p className="font-display text-4xl font-extrabold tabular-nums text-cq-blue sm:text-5xl">+{points}</p>
          <p className="mt-0.5 text-xs font-medium text-ink/60">Charger Points earned</p>
        </div>

        <dl className="mt-3 flex items-center justify-between text-sm">
          <dt className="text-ink/60">Final {meta.scoreLabel.toLowerCase()}</dt>
          <dd className="font-bold tabular-nums text-ink">{formatScore(meta, result.score)}</dd>
        </dl>
        {next &&
        <p className="mt-1 text-left text-xs text-ink/60">
            Reach {formatScore(meta, next.threshold)} for {next.label} · +{next.points} CP
          </p>
        }

        <div className="mt-5 grid grid-cols-2 gap-2">
          <button
            ref={replayRef}
            type="button"
            onClick={onReplay}
            className="flex h-12 items-center justify-center gap-2 rounded-full bg-cq-blue text-sm font-semibold text-white transition-[background-color,transform] duration-150 hover:bg-cq-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cq-blue focus-visible:ring-offset-2 active:scale-[0.97]">
            
            <RotateCcwIcon className="h-4 w-4" /> Replay
          </button>
          <button
            type="button"
            onClick={onNext}
            className="flex h-12 items-center justify-center gap-1.5 whitespace-nowrap rounded-full bg-paper px-3 text-sm font-semibold text-ink transition-[background-color,transform] duration-150 hover:bg-line focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cq-blue focus-visible:ring-offset-2 active:scale-[0.97]"
            aria-label={`Next game: ${nextName}`}>
            
            Next game <ArrowRightIcon className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>);

}