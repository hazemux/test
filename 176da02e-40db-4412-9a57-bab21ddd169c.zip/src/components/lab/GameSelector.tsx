import React from 'react';
import { GamePreview } from './GamePreview';
import { MedalBadge } from './MedalBadge';
import type { GameId, GameMeta } from '../../types/game';

interface GameSelectorProps {
  games: GameMeta[];
  activeId: GameId;
  bests: Partial<Record<GameId, number>>;
  onSelect: (id: GameId) => void;
}

export function GameSelector({ games, activeId, bests, onSelect }: GameSelectorProps) {
  return (
    <nav aria-label="Mini-game concepts" className="min-w-0 lg:sticky lg:top-6">
      <p className="mb-3 hidden text-[13px] font-semibold text-ink/55 lg:block">Six concepts</p>
      <ul className="no-scrollbar -mx-4 flex snap-x snap-mandatory scroll-px-4 gap-2.5 overflow-x-auto px-4 pb-1 sm:gap-3 lg:mx-0 lg:flex-col lg:gap-1.5 lg:overflow-visible lg:px-0">
        {games.map((g) => {
          const active = g.id === activeId;
          const best = bests[g.id];
          return (
            <li key={g.id} className="w-[144px] shrink-0 snap-start sm:w-[164px] lg:w-auto">
              <button
                type="button"
                onClick={() => onSelect(g.id)}
                aria-pressed={active}
                className={`relative flex w-full flex-col gap-2.5 rounded-2xl p-2 text-left transition-[background-color,box-shadow] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cq-blue lg:flex-row lg:items-center lg:gap-3 ${
                active ? 'bg-white shadow-[0_0_0_2px_#007BBF]' : 'bg-white/50 hover:bg-white'}`
                }>
                
                <GamePreview id={g.id} className="aspect-[16/10] w-full shrink-0 rounded-xl lg:aspect-square lg:w-14" />
                <div className="min-w-0 flex-1 px-1 pb-1 lg:p-0">
                  <p className="truncate text-[11px] font-semibold tabular-nums text-ink/50">
                    {g.number} · {g.styleLabel}
                  </p>
                  <p className="truncate font-display text-[15px] font-bold leading-tight text-ink sm:text-[17px]">{g.name}</p>
                </div>
                {best !== undefined && best >= 0 &&
                <span className="absolute right-3 top-3 lg:static lg:mr-2" title={`Best: ${g.tiers[best].label}`}>
                    <MedalBadge medal={g.tiers[best].medal} size={22} />
                    <span className="sr-only">Best reward: {g.tiers[best].label}</span>
                  </span>
                }
              </button>
            </li>);

        })}
      </ul>
    </nav>);

}