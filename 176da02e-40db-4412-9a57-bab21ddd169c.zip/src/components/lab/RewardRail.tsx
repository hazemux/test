import React from 'react';
import { MedalBadge } from './MedalBadge';
import { medalStyles } from '../../data/medals';
import { achievedTierIndex, formatScore } from '../../utils/rewards';
import type { GameMeta, GamePhase } from '../../types/game';

interface RewardRailProps {
  meta: GameMeta;
  score: number;
  phase: GamePhase;
}

export function RewardRail({ meta, score, phase }: RewardRailProps) {
  const achieved = phase === 'ready' ? -1 : achievedTierIndex(score, meta.tiers);
  const next = meta.tiers[achieved + 1];
  const pct = phase === 'ready' ? 0 : Math.min(score / meta.maxScore, 1) * 100;

  const status =
  phase === 'ready' ?
  'Your score sets the reward' :
  next ?
  `${meta.scoreLabel} ${formatScore(meta, score)} · ${next.label} at ${formatScore(meta, next.threshold)}` :
  `${meta.scoreLabel} ${formatScore(meta, score)} · Top tier reached`;

  return (
    <div className="border-y border-line bg-paper/70 px-4 py-3 sm:px-6 sm:py-4">
      <div className="flex items-baseline justify-between gap-3">
        <p className="whitespace-nowrap text-[13px] font-semibold text-ink">Rewards</p>
        <p className="truncate text-[12px] font-medium tabular-nums text-ink/60 sm:text-[13px]" aria-live="polite">
          {status}
        </p>
      </div>

      <div className="relative mt-3 h-2 rounded-full bg-line" aria-hidden="true">
        <div
          className="absolute inset-y-0 left-0 rounded-full bg-cq-blue transition-[width] duration-300"
          style={{ width: `${pct}%`, transitionTimingFunction: 'cubic-bezier(0.23,1,0.32,1)' }} />
        
        {meta.tiers.map((t) =>
        <span
          key={t.medal}
          className="absolute top-1/2 h-4 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-paper"
          style={{
            left: `${Math.max(1, t.threshold / meta.maxScore * 100)}%`,
            background: medalStyles[t.medal].fill
          }} />

        )}
      </div>

      <ol className="mt-3 grid grid-cols-3 gap-2">
        {meta.tiers.map((t, i) => {
          const reached = i <= achieved;
          const isNext = phase === 'playing' && i === achieved + 1;
          const style = medalStyles[t.medal];
          return (
            <li
              key={t.medal}
              className={`flex min-w-0 flex-col items-center gap-1 rounded-xl border px-1.5 py-2 text-center transition-colors duration-200 sm:flex-row sm:gap-2 sm:px-2.5 sm:text-left ${
              reached ? '' : isNext ? 'border-dashed border-ink/30 bg-white' : 'border-line bg-white'}`
              }
              style={reached ? { background: style.soft, borderColor: style.fill } : undefined}>
              
              <MedalBadge medal={t.medal} muted={!reached && !isNext} size={24} />
              <div className="min-w-0 max-w-full">
                <p className="truncate text-[11px] font-medium text-ink/60">
                  <span className="sm:hidden">{style.name}</span>
                  <span className="hidden sm:inline">{t.label}</span>
                </p>
                <p className="whitespace-nowrap text-sm font-bold tabular-nums text-ink">+{t.points} CP</p>
              </div>
            </li>);

        })}
      </ol>
    </div>);

}