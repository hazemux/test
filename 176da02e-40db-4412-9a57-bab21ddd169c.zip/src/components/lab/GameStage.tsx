import React, { useCallback, useRef, useState } from 'react';
import { PlayIcon, RotateCcwIcon, TimerIcon } from 'lucide-react';
import { RewardRail } from './RewardRail';
import { RewardReveal } from './RewardReveal';
import { PerfectPulse } from '../games/PerfectPulse';
import { ShieldReflex } from '../games/ShieldReflex';
import { EnergyBalance } from '../games/EnergyBalance';
import { CoreSequence } from '../games/CoreSequence';
import { EnergyCatch } from '../games/EnergyCatch';
import { CoreFocus } from '../games/CoreFocus';
import { achievedTierIndex } from '../../utils/rewards';
import type { GameId, GameMeta, GamePhase, GameProps, GameResult } from '../../types/game';

interface GameStageProps {
  meta: GameMeta;
  nextName: string;
  onEarn: (id: GameId, points: number, tierIndex: number) => void;
  onNext: () => void;
}

const GAME_COMPONENTS: Record<GameId, React.ComponentType<GameProps>> = {
  pulse: PerfectPulse,
  shield: ShieldReflex,
  balance: EnergyBalance,
  sequence: CoreSequence,
  catch: EnergyCatch,
  focus: CoreFocus
};

export function GameStage({ meta, nextName, onEarn, onNext }: GameStageProps) {
  const [phase, setPhase] = useState<GamePhase>('ready');
  const [runKey, setRunKey] = useState(0);
  const [score, setScore] = useState(0);
  const [result, setResult] = useState<GameResult | null>(null);
  const Game = GAME_COMPONENTS[meta.id];

  const playAreaRef = useRef<HTMLDivElement>(null);

  const start = useCallback(() => {
    setRunKey((k) => k + 1);
    setScore(0);
    setResult(null);
    setPhase('playing');
    // On phones, bring the reward bar + play field fully into view before the run begins.
    if (window.innerWidth < 1024 && playAreaRef.current) {
      const rect = playAreaRef.current.getBoundingClientRect();
      if (rect.top < 0 || rect.bottom > window.innerHeight) {
        const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        playAreaRef.current.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
      }
    }
  }, []);

  const handleProgress = useCallback((s: number) => setScore(s), []);

  const handleComplete = useCallback(
    (r: GameResult) => {
      const idx = achievedTierIndex(r.score, meta.tiers);
      onEarn(meta.id, idx >= 0 ? meta.tiers[idx].points : 0, idx);
      setScore(r.score);
      setResult(r);
      setPhase('done');
    },
    [meta, onEarn]
  );

  return (
    <section
      aria-labelledby="stage-title"
      className="-mx-4 min-w-0 overflow-hidden border-y border-line bg-white sm:mx-0 sm:rounded-[28px] sm:border-x">
      
      <header className="flex items-start justify-between gap-3 px-4 pb-4 pt-5 sm:gap-4 sm:px-6">
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold tabular-nums text-cq-blue">
            {meta.number} · {meta.styleLabel}
          </p>
          <h2 id="stage-title" className="mt-0.5 font-display text-[22px] font-bold leading-tight text-ink sm:text-3xl">
            {meta.name}
          </h2>
          <p className="mt-1.5 max-w-xl text-[13px] leading-relaxed text-ink/65 sm:text-sm">{meta.instruction}</p>
        </div>
        {phase === 'ready' ?
        <span className="flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full bg-paper px-3 text-xs font-semibold text-ink/70">
            <TimerIcon className="h-3.5 w-3.5" /> {meta.playTime}
          </span> :

        <button
          type="button"
          onClick={start}
          className="flex h-9 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full bg-paper px-3 text-xs font-semibold text-ink transition-colors duration-150 hover:bg-line focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cq-blue">
          
            <RotateCcwIcon className="h-3.5 w-3.5" /> Restart
          </button>
        }
      </header>

      <div ref={playAreaRef} className="scroll-mt-2">
      <RewardRail meta={meta} score={score} phase={phase} />

      <div className="relative h-[clamp(420px,calc(100svh-190px),620px)] overflow-hidden sm:h-auto sm:aspect-[16/11] lg:aspect-auto lg:h-[560px]">
        <Game key={runKey} phase={phase} onProgress={handleProgress} onComplete={handleComplete} />

        {phase === 'ready' &&
          <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex justify-center p-4 sm:p-6">
            <button
              type="button"
              onClick={start}
              className="anim-rise pointer-events-auto flex h-14 max-w-full items-center gap-2.5 whitespace-nowrap rounded-full bg-ink pl-4 pr-6 text-[15px] font-semibold text-white shadow-[0_12px_30px_-10px_rgba(14,26,36,0.6)] transition-[background-color,transform] duration-150 hover:bg-cq-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cq-yellow focus-visible:ring-offset-2 active:scale-[0.97]">
              
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-cq-yellow text-ink">
                <PlayIcon className="ml-0.5 h-4 w-4 fill-current" />
              </span>
              Play {meta.name}
            </button>
          </div>
          }

        {phase === 'done' && result &&
          <RewardReveal meta={meta} result={result} nextName={nextName} onReplay={start} onNext={onNext} />
          }
      </div>
      </div>
    </section>);

}