import React from 'react';
import { ZapIcon } from 'lucide-react';

interface LabHeaderProps {
  wallet: number;
}

export function LabHeader({ wallet }: LabHeaderProps) {
  return (
    <header className="mx-auto flex max-w-[1240px] items-center justify-between gap-3 px-4 py-3 sm:gap-4 sm:px-6 sm:py-4">
      <a href="https://chargerquick.net" className="flex items-center gap-2.5 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cq-blue">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-cq-blue">
          <ZapIcon className="h-5 w-5 fill-cq-yellow text-cq-yellow" />
        </span>
        <span className="whitespace-nowrap font-display text-lg font-bold text-ink">Charger Quick</span>
      </a>
      <div className="flex items-center gap-2 whitespace-nowrap rounded-full border border-line bg-white py-1.5 pl-3 pr-1.5">
        <span className="hidden text-xs font-medium text-ink/55 sm:inline">Lab wallet</span>
        <span className="flex items-center gap-1 rounded-full bg-cq-yellow px-2.5 py-1 text-sm font-bold tabular-nums text-ink">
          <ZapIcon className="h-3.5 w-3.5 fill-current" />
          <span key={wallet} className="anim-enter inline-block">
            {wallet}
          </span>{' '}
          CP
        </span>
      </div>
    </header>);

}