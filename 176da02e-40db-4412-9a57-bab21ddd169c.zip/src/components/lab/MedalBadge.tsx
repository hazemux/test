import React from 'react';
import { medalStyles } from '../../data/medals';
import type { Medal } from '../../types/game';

interface MedalBadgeProps {
  medal: Medal;
  size?: number;
  muted?: boolean;
  className?: string;
}

export function MedalBadge({ medal, size = 28, muted = false, className = '' }: MedalBadgeProps) {
  const style = medalStyles[medal];
  const fill = muted ? '#E7E2D7' : style.fill;
  const deep = muted ? '#C4BCAC' : style.deep;

  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true" className={`shrink-0 ${className}`}>
      <path d="M24 2 L43 13 L43 35 L24 46 L5 35 L5 13 Z" fill={deep} />
      <path d="M24 6 L39.5 15 L39.5 33 L24 42 L8.5 33 L8.5 15 Z" fill={fill} />
      <path d="M24 6 L39.5 15 L24 24 L8.5 15 Z" fill="#FFFFFF" opacity={muted ? 0.35 : 0.24} />
      <path d="M26.5 13 L17.5 26.5 H23.5 L21.5 35 L30.5 21.5 H24.5 Z" fill={muted ? '#FFFFFF' : deep} />
    </svg>);

}