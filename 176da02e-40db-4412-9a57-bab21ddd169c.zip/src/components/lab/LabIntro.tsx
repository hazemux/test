import React from 'react';
import { MedalBadge } from './MedalBadge';
import { medalStyles } from '../../data/medals';
import type { Medal } from '../../types/game';

const SCALE: {medal: Medal;points: number;}[] = [
{ medal: 'bronze', points: 5 },
{ medal: 'silver', points: 15 },
{ medal: 'gold', points: 30 }];


export function LabIntro() {
  return (
    <section className="grid gap-5 pb-1 pt-2 sm:gap-6 sm:pt-8 lg:grid-cols-[1fr_auto] lg:items-end lg:gap-12">
      <div className="min-w-0">
        <h1 className="font-display text-[clamp(32px,9.5vw,40px)] font-extrabold leading-[1.02] tracking-tight text-ink sm:text-6xl">
          Core Defender Lab
        </h1>
        <p className="mt-3 max-w-xl text-[15px] leading-relaxed text-ink/65 sm:text-base">
          Six ways to defend the Core. Each concept is a 3–10 second skill game — play them back to back,
          compare how they feel, and watch your performance decide the reward.
        </p>
      </div>
      <div>
        <p className="text-[13px] font-semibold text-ink">Skill sets the reward — no random drops</p>
        <ul className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 sm:gap-5">
          {SCALE.map((s) =>
          <li key={s.medal} className="flex items-center gap-2">
              <MedalBadge medal={s.medal} size={30} />
              <div>
                <p className="text-[11px] font-medium text-ink/55">{medalStyles[s.medal].name}</p>
                <p className="whitespace-nowrap text-sm font-bold tabular-nums text-ink">+{s.points} CP</p>
              </div>
            </li>
          )}
        </ul>
      </div>
    </section>);

}