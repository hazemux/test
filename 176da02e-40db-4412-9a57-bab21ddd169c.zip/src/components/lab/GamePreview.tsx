import React from 'react';
import type { GameId } from '../../types/game';

interface GamePreviewProps {
  id: GameId;
  className?: string;
}

const BACKGROUNDS: Record<GameId, string> = {
  pulse: '#F3EFE6',
  shield: '#071A2C',
  balance: '#E2EDF5',
  sequence: '#0B0D10',
  catch: '#FFF1C9',
  focus: '#007BBF'
};

export function GamePreview({ id, className = '' }: GamePreviewProps) {
  return (
    <svg
      viewBox="0 0 160 100"
      preserveAspectRatio="xMidYMid slice"
      className={className}
      style={{ background: BACKGROUNDS[id] }}
      aria-hidden="true">
      
      {id === 'pulse' &&
      <g transform="translate(80 50)">
          <circle r="44" fill="none" stroke="#007BBF" strokeOpacity="0.14" />
          <circle r="28" fill="none" stroke="#FFBE32" strokeOpacity="0.5" strokeWidth="9" />
          <circle r="28" fill="none" stroke="#E8A100" strokeWidth="2" />
          <circle r="38" fill="none" stroke="#007BBF" strokeWidth="2" />
          <circle r="14" fill="#007BBF" />
          <path d="M0 -14 A14 14 0 0 1 12.1 7 L0 0Z" fill="#1E90CF" />
          <circle r="6" fill="#F3EFE6" />
          <circle r="3.5" fill="#FFBE32" />
        </g>
      }
      {id === 'shield' &&
      <g transform="translate(80 50)">
          <circle r="24" fill="none" stroke="#8ED3FF" strokeOpacity="0.5" strokeDasharray="2 3" />
          <path d="M-20 -14 A24 24 0 0 1 20 -14" fill="none" stroke="#8ED3FF" strokeWidth="4" strokeLinecap="round" />
          <polygon points="0,-12 10.4,-6 10.4,6 0,12 -10.4,6 -10.4,-6" fill="#007BBF" />
          <polygon points="0,-12 10.4,-6 0,0 -10.4,-6" fill="#2A9AD8" />
          <circle r="3" fill="#FFBE32" />
          <g transform="translate(46 -32) rotate(146)">
            <line x1="-4" y1="0" x2="-22" y2="0" stroke="#FFBE32" strokeOpacity="0.4" strokeWidth="2" />
            <polygon points="6,0 -2,-4 -5,0 -2,4" fill="#FFBE32" />
          </g>
        </g>
      }
      {id === 'balance' &&
      <g>
          <rect x="68" y="14" width="24" height="34" rx="4" fill="#FFFFFF" />
          <rect x="68" y="30" width="24" height="18" rx="2" fill="#007BBF" />
          <rect x="70" y="9" width="20" height="7" rx="2" fill="#FFBE32" />
          <rect x="24" y="64" width="112" height="22" rx="11" fill="#A9C7DC" />
          <rect x="24" y="60" width="112" height="22" rx="11" fill="#FFFFFF" />
          <rect x="30" y="64" width="100" height="14" rx="7" fill="#EAF2F8" />
          <rect x="80" y="64" width="18" height="14" rx="4" fill="#FFBE32" />
          <rect x="102" y="61" width="5" height="20" rx="2.5" fill="#007BBF" />
        </g>
      }
      {id === 'sequence' &&
      <g transform="translate(80 50)">
          {Array.from({ length: 6 }, (_, i) => {
          const a = (-90 + i * 60) * Math.PI / 180;
          const x = Math.cos(a) * 32;
          const y = Math.sin(a) * 32;
          const on = i === 1;
          return (
            <g key={i}>
                <line x1={x * 0.35} y1={y * 0.35} x2={x * 0.75} y2={y * 0.75} stroke={on ? '#FFBE32' : '#FFFFFF'} strokeOpacity={on ? 0.8 : 0.12} />
                <circle cx={x} cy={y} r="7" fill={on ? '#FFBE32' : '#14181E'} stroke="#FFFFFF" strokeOpacity={on ? 0 : 0.25} />
              </g>);

        })}
          <circle r="10" fill="#007BBF" />
          <circle r="4" fill="#0B0D10" />
        </g>
      }
      {id === 'catch' &&
      <g>
          <circle cx="80" cy="50" r="54" fill="#FFE29A" />
          <circle cx="80" cy="50" r="16" fill="#007BBF" />
          <circle cx="80" cy="50" r="10" fill="#00609A" />
          <g transform="translate(42 28)">
            <polygon points="0,-9 7.8,-4.5 7.8,4.5 0,9 -7.8,4.5 -7.8,-4.5" fill="#007BBF" />
            <polygon points="0,-9 7.8,-4.5 0,0 -7.8,-4.5" fill="#3AA6E0" />
          </g>
          <path transform="translate(120 68)" d="M0 -11 L3 -3 L11 0 L3 3 L0 11 L-3 3 L-11 0 L-3 -3Z" fill="#F5A400" stroke="#9A6500" />
          <g transform="translate(116 26)">
            <circle r="7" fill="#2A2747" />
            <circle r="2.5" fill="#A78BFA" />
          </g>
          <g transform="translate(46 74)">
            <polygon points="0,-7 6,-3.5 6,3.5 0,7 -6,3.5 -6,-3.5" fill="#007BBF" />
          </g>
        </g>
      }
      {id === 'focus' &&
      <g>
          <defs>
            <pattern id="preview-focus-dots" width="10" height="10" patternUnits="userSpaceOnUse">
              <circle cx="5" cy="5" r="0.9" fill="#FFFFFF" fillOpacity="0.25" />
            </pattern>
          </defs>
          <rect width="160" height="100" fill="url(#preview-focus-dots)" />
          <circle cx="50" cy="66" r="12" fill="none" stroke="#00476F" strokeWidth="3" />
          <g transform="translate(108 38)">
            <circle r="17" fill="none" stroke="#FFFFFF" strokeOpacity="0.25" strokeWidth="2" />
            <path d="M0 -17 A17 17 0 1 1 -14.7 8.5" fill="none" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
            <circle r="12" fill="#FFBE32" />
            <circle r="6" fill="#007BBF" />
          </g>
        </g>
      }
    </svg>);

}