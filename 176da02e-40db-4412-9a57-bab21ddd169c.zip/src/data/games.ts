import type { GameMeta } from '../types/game';

export const games: GameMeta[] = [
{
  id: 'pulse',
  number: '01',
  name: 'Perfect Pulse',
  styleLabel: 'Clean geometric',
  instruction:
  'Tap when the moving ring crosses the golden band. The thinner the line you hit, the bigger the reward.',
  scoreLabel: 'Accuracy',
  scoreUnit: '%',
  maxScore: 100,
  playTime: '~3s',
  tiers: [
  { medal: 'bronze', label: 'Any Hit', points: 5, threshold: 1 },
  { medal: 'silver', label: 'Good Hit', points: 15, threshold: 60 },
  { medal: 'gold', label: 'Perfect Hit', points: 30, threshold: 90 }]

},
{
  id: 'shield',
  number: '02',
  name: 'Shield Reflex',
  styleLabel: 'Futuristic arcade',
  instruction:
  'Three attacks incoming. Tap to raise the shield as late as you dare — just before each projectile touches the dashed ring.',
  scoreLabel: 'Defense',
  scoreUnit: ' pts',
  maxScore: 30,
  playTime: '~6s',
  tiers: [
  { medal: 'bronze', label: 'Basic Defense', points: 5, threshold: 3 },
  { medal: 'silver', label: 'Strong Defense', points: 15, threshold: 15 },
  { medal: 'gold', label: 'Perfect Defense', points: 30, threshold: 26 }]

},
{
  id: 'balance',
  number: '03',
  name: 'Energy Balance',
  styleLabel: 'Soft 2.5D',
  instruction:
  'Tap to stop the charge inside the yellow zone. Each of the three attempts gets narrower and faster.',
  scoreLabel: 'Hits',
  scoreUnit: '/3',
  maxScore: 3,
  playTime: '~6s',
  tiers: [
  { medal: 'bronze', label: 'One Hit', points: 5, threshold: 1 },
  { medal: 'silver', label: 'Two Hits', points: 15, threshold: 2 },
  { medal: 'gold', label: 'Three Hits', points: 30, threshold: 3 }]

},
{
  id: 'sequence',
  number: '04',
  name: 'Core Sequence',
  styleLabel: 'Minimal dark arcade',
  instruction:
  'Watch the nodes light up, then tap them in the same order. Patterns grow from 3 to 4 to 5 nodes.',
  scoreLabel: 'Sequences',
  scoreUnit: '/3',
  maxScore: 3,
  playTime: '~10s',
  tiers: [
  { medal: 'bronze', label: 'Basic Sequence', points: 5, threshold: 1 },
  { medal: 'silver', label: 'Advanced Sequence', points: 15, threshold: 2 },
  { medal: 'gold', label: 'Perfect Sequence', points: 30, threshold: 3 }]

},
{
  id: 'catch',
  number: '05',
  name: 'Energy Catch',
  styleLabel: 'Bright casual',
  instruction:
  'Tap blue and golden fragments before they fade. Dark energy drains your score — leave it alone.',
  scoreLabel: 'Energy',
  scoreUnit: ' pts',
  maxScore: 180,
  playTime: '8s',
  tiers: [
  { medal: 'bronze', label: 'Bronze Score', points: 5, threshold: 40 },
  { medal: 'silver', label: 'Silver Score', points: 15, threshold: 90 },
  { medal: 'gold', label: 'Gold Score', points: 30, threshold: 150 }]

},
{
  id: 'focus',
  number: '06',
  name: 'Core Focus',
  styleLabel: 'Playful modern',
  instruction:
  'Tap the Core every time it appears. It blinks out faster each round — eight appearances in total.',
  scoreLabel: 'Caught',
  scoreUnit: '/8',
  maxScore: 8,
  playTime: '~8s',
  tiers: [
  { medal: 'bronze', label: 'Basic Performance', points: 5, threshold: 3 },
  { medal: 'silver', label: 'Good Performance', points: 15, threshold: 6 },
  { medal: 'gold', label: 'Perfect Performance', points: 30, threshold: 8 }]

}];