import type { Medal } from '../types/game';

export const medalStyles: Record<Medal, {name: string;fill: string;deep: string;soft: string;}> = {
  bronze: { name: 'Bronze', fill: '#D08A55', deep: '#8E5427', soft: '#F8E7D8' },
  silver: { name: 'Silver', fill: '#A7B4C2', deep: '#55667A', soft: '#EAEFF4' },
  gold: { name: 'Gold', fill: '#FFBE32', deep: '#9A6500', soft: '#FFF2CF' }
};