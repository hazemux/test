import React, { useCallback, useState } from 'react';
import { LabHeader } from './components/lab/LabHeader';
import { LabIntro } from './components/lab/LabIntro';
import { GameSelector } from './components/lab/GameSelector';
import { GameStage } from './components/lab/GameStage';
import { games } from './data/games';
import type { GameId } from './types/game';

export function App() {
  const [activeId, setActiveId] = useState<GameId>('catch');
  const [wallet, setWallet] = useState(0);
  const [bests, setBests] = useState<Partial<Record<GameId, number>>>({});

  const activeIndex = games.findIndex((g) => g.id === activeId);
  const active = games[activeIndex];
  const next = games[(activeIndex + 1) % games.length];

  const handleEarn = useCallback((id: GameId, points: number, tierIndex: number) => {
    setWallet((w) => w + points);
    setBests((b) => ({ ...b, [id]: Math.max(b[id] ?? -1, tierIndex) }));
  }, []);

  return (
    <div className="min-h-screen w-full overflow-x-clip bg-paper text-ink">
      <LabHeader wallet={wallet} />
      <main className="mx-auto max-w-[1240px] px-4 pb-10 sm:px-6 sm:pb-16">
        <LabIntro />
        <div className="mt-5 grid grid-cols-[minmax(0,1fr)] gap-4 sm:mt-6 sm:gap-5 lg:mt-10 lg:grid-cols-[288px_minmax(0,1fr)] lg:items-start lg:gap-8">
          <GameSelector games={games} activeId={activeId} bests={bests} onSelect={setActiveId} />
          <GameStage
            key={activeId}
            meta={active}
            nextName={next.name}
            onEarn={handleEarn}
            onNext={() => setActiveId(next.id)} />
          
        </div>
        <p className="mt-6 text-center text-xs text-ink/45">
          Prototype · Charger Points are simulated and reset when you reload.
        </p>
      </main>
    </div>);

}