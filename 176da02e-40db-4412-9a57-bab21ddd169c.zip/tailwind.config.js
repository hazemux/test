export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        cq: {
          blue: '#007BBF',
          deep: '#00507D',
          yellow: '#FFBE32',
          amber: '#E8A100',
        },
        ink: '#0E1A24',
        paper: '#F5F3EE',
        line: '#E3DED2',
        coral: '#E8553E',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'Inter', 'sans-serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
};
